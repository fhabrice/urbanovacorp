-- =====================================================================
-- URBANOVA SOLUTIONS — Mise à jour du schéma (Modules 1-2-3)
-- Généré automatiquement. Idempotent : peut être exécuté plusieurs fois.
-- Compatible MySQL 5.7+ / MariaDB 10.x (vérifications information_schema).
--
-- IMPORTATION :
--   phpMyAdmin : sélectionner la base "wqmetrvw_urbanova" puis Importer ce fichier
--   CLI : mysql -u wqmetrvw_urbanova -p wqmetrvw_urbanova < database/upgrade_schema.sql
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------------------
-- 1. TABLE INVESTORS (si absente) — profil KYC investisseur
-- -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS investors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('individual', 'corporate') NOT NULL DEFAULT 'individual',
    investor_type ENUM('business_angel', 'individual', 'family_office', 'investment_fund', 'bank', 'investment_company', 'dfi', 'corporate_venture', 'other') NOT NULL DEFAULT 'individual',
    investor_status ENUM('pending', 'approved', 'rejected', 'additional_info') NOT NULL DEFAULT 'pending',
    nationality VARCHAR(100),
    phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100),
    id_document_type VARCHAR(50),
    id_document_number VARCHAR(100),
    id_document_expiry DATE,
    company_name VARCHAR(255),
    company_registration_number VARCHAR(100),
    company_tax_id VARCHAR(100),
    investment_capacity DECIMAL(15,2),
    investment_sectors TEXT,
    risk_profile ENUM('conservative', 'moderate', 'aggressive'),
    kyc_documents JSON,
    kyc_submitted_at TIMESTAMP NULL,
    kyc_reviewed_at TIMESTAMP NULL,
    kyc_reviewed_by INT NULL,
    rejection_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_investor_status (investor_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------
-- 2. TABLES DES MODULES (créées seulement si absentes)
-- -----------------------------------------------------------------

CREATE TABLE IF NOT EXISTS project_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    document_type ENUM('business_plan', 'financial_model', 'due_diligence', 'legal', 'technical', 'other') NOT NULL,
    title VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    is_confidential BOOLEAN DEFAULT TRUE,
    uploaded_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_document_type (document_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS investor_interests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    investor_id INT NOT NULL,
    interest_type ENUM('view', 'inquiry', 'nda_signed', 'negotiation') NOT NULL DEFAULT 'view',
    investment_amount DECIMAL(15,2),
    message TEXT,
    nda_signed BOOLEAN DEFAULT FALSE,
    nda_signed_at TIMESTAMP NULL,
    status ENUM('pending', 'accepted', 'rejected', 'closed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (investor_id) REFERENCES investors(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_investor_id (investor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS investor_favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    investor_id INT NOT NULL,
    project_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (investor_id) REFERENCES investors(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    UNIQUE KEY unique_favorite (investor_id, project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS investor_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    investor_id INT NOT NULL,
    project_id INT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
    admin_reply TEXT NULL,
    admin_replied_at TIMESTAMP NULL,
    admin_replied_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (investor_id) REFERENCES investors(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_replied_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_investor_id (investor_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS project_visits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NULL,
    visitor_name VARCHAR(255) NOT NULL,
    visitor_email VARCHAR(255) NOT NULL,
    visitor_phone VARCHAR(50),
    preferred_date DATE NOT NULL,
    preferred_time TIME NOT NULL,
    message TEXT,
    status ENUM('pending', 'confirmed', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_project_id (project_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS project_reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(50),
    reservation_type ENUM('sale', 'rental') NOT NULL,
    unit_number VARCHAR(100),
    amount DECIMAL(15,2),
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_project_id (project_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS funding_campaigns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    target_amount DECIMAL(15,2) NOT NULL,
    minimum_investment DECIMAL(15,2),
    maximum_investment DECIMAL(15,2),
    commission_rate DECIMAL(5,2) DEFAULT 3.00,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('draft', 'active', 'paused', 'completed', 'cancelled') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS investment_offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    campaign_id INT NOT NULL,
    investor_id INT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    message TEXT,
    status ENUM('pending', 'under_review', 'accepted', 'rejected', 'withdrawn') DEFAULT 'pending',
    reviewed_at TIMESTAMP NULL,
    reviewed_by INT NULL,
    rejection_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (campaign_id) REFERENCES funding_campaigns(id) ON DELETE CASCADE,
    FOREIGN KEY (investor_id) REFERENCES investors(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_campaign_id (campaign_id),
    INDEX idx_investor_id (investor_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS data_room_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    investor_id INT NOT NULL,
    permission_level ENUM('view_only', 'download_allowed', 'full_access', 'temporary') DEFAULT 'view_only',
    expires_at TIMESTAMP NULL,
    status ENUM('active', 'revoked', 'expired') DEFAULT 'active',
    granted_by INT NOT NULL,
    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (investor_id) REFERENCES investors(id) ON DELETE CASCADE,
    FOREIGN KEY (granted_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_project_investor (project_id, investor_id),
    INDEX idx_project_id (project_id),
    INDEX idx_investor_id (investor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS data_room_audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    investor_id INT NOT NULL,
    action ENUM('access_granted', 'access_denied', 'document_viewed', 'document_downloaded', 'access_revoked', 'permission_changed') NOT NULL,
    document_id INT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (investor_id) REFERENCES investors(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_investor_id (investor_id),
    INDEX idx_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('project_status', 'investment_update', 'visit_request', 'reservation', 'kyc_status', 'message', 'system', 'funding', 'mandate', 'offer', 'data_room', 'inquiry') NOT NULL DEFAULT 'system',
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    link VARCHAR(500) NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS funding_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    summary TEXT,
    amount_requested DECIMAL(15,2),
    status ENUM('pending_study', 'under_review', 'accepted', 'requested_info', 'rejected', 'closed', 'cancelled') DEFAULT 'pending_study',
    commission_rate DECIMAL(5,2) NULL,
    mandate_reference VARCHAR(100) NULL,
    mandate_date DATE NULL,
    admin_notes TEXT,
    decided_by INT NULL,
    decided_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (decided_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_project_id (project_id),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS data_room_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    investor_id INT NOT NULL,
    requested_level ENUM('view_only', 'download_allowed', 'full_access', 'temporary') DEFAULT 'view_only',
    justification TEXT,
    status ENUM('pending', 'approved', 'refused', 'revoked', 'expired') DEFAULT 'pending',
    granted_permission_id INT NULL,
    decided_by INT NULL,
    decided_at TIMESTAMP NULL,
    refusal_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (investor_id) REFERENCES investors(id) ON DELETE CASCADE,
    FOREIGN KEY (granted_permission_id) REFERENCES data_room_permissions(id) ON DELETE SET NULL,
    FOREIGN KEY (decided_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_project_id (project_id),
    INDEX idx_investor_id (investor_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS project_inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    message TEXT,
    status ENUM('new', 'in_progress', 'resolved', 'closed') DEFAULT 'new',
    admin_note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    module VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS role_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role ENUM('super_admin', 'admin', 'project_manager', 'promoter', 'investor', 'client') NOT NULL,
    permission_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
    UNIQUE KEY unique_role_permission (role, permission_id),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------
-- 3. COLONNES MANQUANTES SUR LES TABLES EXISTANTES
--    (identifiant la table avant la modification; si absente, ignoré)
-- -----------------------------------------------------------------

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'first_name');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE users ADD COLUMN first_name VARCHAR(100) NOT NULL DEFAULT ''', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'last_name');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE users ADD COLUMN last_name VARCHAR(100) NOT NULL DEFAULT ''', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'user_id');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN user_id INT NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'validation_status');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN validation_status VARCHAR(50) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'project_type');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN project_type VARCHAR(50) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'operation_type');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN operation_type VARCHAR(50) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'coordinates_lat');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN coordinates_lat DECIMAL(10,8) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'coordinates_lng');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN coordinates_lng DECIMAL(11,8) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'video_url');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN video_url VARCHAR(500) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'virtual_tour_url');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN virtual_tour_url VARCHAR(500) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'google_maps_embed');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN google_maps_embed TEXT NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'brochure_path');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN brochure_path VARCHAR(255) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'availability');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN availability VARCHAR(100) DEFAULT 'available'', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'price');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN price DECIMAL(15,2) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'latitude');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN latitude DECIMAL(10,8) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'longitude');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN longitude DECIMAL(11,8) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'slug');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN slug VARCHAR(255) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'promoter');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN promoter VARCHAR(255) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'promoter_id');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN promoter_id INT NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'funding_raised');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN funding_raised DECIMAL(15,2) DEFAULT 0', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'expected_roi');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN expected_roi DECIMAL(5,2) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'total_cost');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN total_cost DECIMAL(15,2) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'roi');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN roi DECIMAL(5,2) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'housing_units');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN housing_units INT DEFAULT 0', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'jobs_created');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE projects ADD COLUMN jobs_created INT DEFAULT 0', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'investor_type');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN investor_type ENUM('business_angel', 'individual', 'family_office', 'investment_fund', 'bank', 'investment_company', 'dfi', 'corporate_venture', 'other') NOT NULL DEFAULT 'individual'', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'investor_status');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN investor_status ENUM('pending', 'approved', 'rejected', 'additional_info') NOT NULL DEFAULT 'pending'', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'nationality');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN nationality VARCHAR(100) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'company_name');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN company_name VARCHAR(255) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'investment_capacity');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN investment_capacity DECIMAL(15,2) NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'investment_sectors');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN investment_sectors TEXT NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'risk_profile');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN risk_profile ENUM('conservative', 'moderate', 'aggressive') NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'kyc_documents');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN kyc_documents JSON NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'kyc_submitted_at');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN kyc_submitted_at TIMESTAMP NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'kyc_reviewed_at');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN kyc_reviewed_at TIMESTAMP NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'kyc_reviewed_by');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN kyc_reviewed_by INT NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investors' AND COLUMN_NAME = 'rejection_reason');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investors ADD COLUMN rejection_reason TEXT NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investor_messages');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'investor_messages' AND COLUMN_NAME = 'project_id');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE investor_messages ADD COLUMN project_id INT NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @tbl := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'data_room_permissions');
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'data_room_permissions' AND COLUMN_NAME = 'status');
SET @sql := IF(@tbl = 1 AND @col = 0, 'ALTER TABLE data_room_permissions ADD COLUMN status ENUM('active', 'revoked', 'expired') DEFAULT 'active'', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;


-- -----------------------------------------------------------------
-- 4. ÉLARGISSEMENT DES ENUMS (sans perte de données)
-- -----------------------------------------------------------------
SET @sql := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'role') = 1,
  'ALTER TABLE users MODIFY COLUMN role ENUM(''admin'', ''super_admin'', ''project_manager'', ''promoter'', ''investor'', ''client'') NOT NULL DEFAULT ''investor''',
  'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'status') = 1,
  'ALTER TABLE projects MODIFY COLUMN status ENUM(''draft'', ''submitted'', ''under_review'', ''approved'', ''rejected'', ''funded'', ''completed'', ''published'', ''suspended'', ''sold'', ''rented'', ''archived'') NOT NULL DEFAULT ''draft''',
  'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- -----------------------------------------------------------------
-- 5. PERMISSIONS RBAC (INSERT IGNORE = idempotent)
-- -----------------------------------------------------------------
INSERT IGNORE INTO permissions (name, description, module) VALUES
('manage_users', 'Gérer les utilisateurs', 'admin'),
('manage_projects', 'Gérer tous les projets', 'admin'),
('validate_projects', 'Valider les projets', 'admin'),
('manage_investors', 'Gérer les investisseurs', 'admin'),
('manage_campaigns', 'Gérer les campagnes de financement', 'admin'),
('view_analytics', 'Voir les statistiques', 'admin'),
('manage_own_projects', 'Gérer ses propres projets', 'promoter'),
('view_projects', 'Voir les projets', 'investor'),
('submit_offers', 'Soumettre des offres d''investissement', 'investor'),
('access_dataroom', 'Accéder à la Data Room', 'investor'),
('view_marketplace', 'Voir la marketplace', 'client'),
('request_visits', 'Demander des visites', 'client'),
('make_reservations', 'Faire des réservations', 'client');

INSERT IGNORE INTO role_permissions (role, permission_id)
SELECT 'super_admin', id FROM permissions;
INSERT IGNORE INTO role_permissions (role, permission_id)
SELECT 'admin', id FROM permissions WHERE module = 'admin';
INSERT IGNORE INTO role_permissions (role, permission_id)
SELECT 'project_manager', id FROM permissions WHERE name IN ('manage_projects', 'validate_projects', 'view_analytics');
INSERT IGNORE INTO role_permissions (role, permission_id)
SELECT 'promoter', id FROM permissions WHERE name = 'manage_own_projects';
INSERT IGNORE INTO role_permissions (role, permission_id)
SELECT 'investor', id FROM permissions WHERE name IN ('view_projects', 'submit_offers', 'access_dataroom');
INSERT IGNORE INTO role_permissions (role, permission_id)
SELECT 'client', id FROM permissions WHERE name IN ('view_marketplace', 'request_visits', 'make_reservations');


-- =====================================================================
-- CMS : contenus gérables depuis l'espace admin (projets phares,
-- actualités, textes du site). Idempotent.
-- =====================================================================

-- 1. Actualités (news)
CREATE TABLE IF NOT EXISTS news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    excerpt VARCHAR(500),
    content TEXT,
    category ENUM('entreprise', 'projets', 'marché', 'partenariats') NOT NULL DEFAULT 'entreprise',
    image VARCHAR(512),
    author_id INT NULL,
    status ENUM('draft', 'published') DEFAULT 'draft',
    deleted_at DATETIME NULL,
    published_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Contenus du site (site_content)
CREATE TABLE IF NOT EXISTS site_content (
    id INT AUTO_INCREMENT PRIMARY KEY,
    content_key VARCHAR(100) NOT NULL UNIQUE,
    content_value MEDIUMTEXT,
    category VARCHAR(50) DEFAULT 'general',
    updated_by INT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Colonne is_featured sur projects (projets phares)
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'is_featured');
SET @sql = IF(@col_exists = 0,
    'ALTER TABLE projects ADD COLUMN is_featured TINYINT(1) NOT NULL DEFAULT 0',
    'SELECT 1');
PREPARE stmt_featured FROM @sql;
EXECUTE stmt_featured;
DEALLOCATE PREPARE stmt_featured;

SET @idx_exists = (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND INDEX_NAME = 'idx_featured');
SET @sql = IF(@idx_exists = 0,
    'ALTER TABLE projects ADD INDEX idx_featured (is_featured)',
    'SELECT 1');
PREPARE stmt_idx FROM @sql;
EXECUTE stmt_idx;
DEALLOCATE PREPARE stmt_idx;

-- 4. Valeurs par défaut des contenus du site (INSERT IGNORE)
INSERT IGNORE INTO site_content (content_key, content_value, category) VALUES
('hero_pretitle', 'URBANOVA SOLUTIONS', 'home'),
('hero_title', 'Structurer les villes', 'home'),
('hero_title_highlight', 'africaines de demain', 'home'),
('hero_subtitle', 'Construction, Immobilier, Infrastructures et Investissements pour un développement durable en République Démocratique du Congo et Afrique Centrale.', 'home'),
('stats_projects_value', '120+', 'home'),
('stats_projects_label', 'Projets réalisés', 'home'),
('stats_investments_value', '45 M$', 'home'),
('stats_investments_label', 'Investissements mobilisés', 'home'),
('stats_housing_value', '2 500', 'home'),
('stats_housing_label', 'Logements développés', 'home'),
('stats_jobs_value', '5 000', 'home'),
('stats_jobs_label', 'Emplois créés', 'home'),
('stats_countries_value', '4', 'home'),
('stats_countries_label', 'Pays d''intervention', 'home'),
('stats_countries_detail', 'RDC • Rwanda • Ouganda • Burundi', 'home'),
('departments_title', 'Nos Départements', 'home'),
('departments_items', '[{"icon": "fa-solid fa-helmet-safety", "title": "Construction & Maintenance", "text": "Édification et entretien d''ouvrages durables, respectueux de l''environnement et des standards de sécurité modernes."}, {"icon": "fa-solid fa-trash-can", "title": "Assainissement & Déchets", "text": "Gestion environnementale intégrée, tri, recyclage et propreté urbaine pour préserver la santé publique."}, {"icon": "fa-solid fa-building-circle-check", "title": "Facility Management", "text": "Exploitation, sécurisation, et maintenance d''infrastructures d''envergure pour prolonger la durée de vie de vos actifs."}, {"icon": "fa-solid fa-house-chimney-window", "title": "Immobilier & Aménagement", "text": "Promotion immobilière et aménagement de zones urbaines intégrées favorisant la mixité sociale et économique."}, {"icon": "fa-solid fa-compass-drafting", "title": "Ingénierie", "text": "Assistance technique de haut niveau, études de sol, architecture moderne et conception modulaire de projets."}, {"icon": "fa-solid fa-leaf", "title": "Développement durable", "text": "Conception d''infrastructures à fort impact environnemental positif (énergies renouvelables, captage d''eau)."}]', 'home'),
('cta_promoter_title', 'Vous avez un projet immobilier ?', 'home'),
('cta_promoter_text', 'Soumettez votre dossier technique, profitez d''une validation d''experts et accédez à notre réseau international d''investisseurs certifiés.', 'home'),
('cta_investor_title', 'Vous êtes investisseur ?', 'home'),
('cta_investor_text', 'Rejoignez notre écosystème d''investisseurs, explorez des opportunités qualifiées et suivez vos rendements via notre tableau de bord de pointe.', 'home'),
('departments_text', 'Une expertise multisectorielle au service du développement urbain durable en République Démocratique du Congo.', 'home'),
('featured_title', 'Projets phares', 'home'),
('featured_text', 'Découvrez nos réalisations majeures en cours d''exécution ou livrées avec succès sur le continent.', 'home'),
('about_mission', 'Concevoir, développer et opérer des solutions urbaines durables à fort impact pour restructurer durablement l''environnement urbain et mobiliser des capitaux qualifiés.', 'about'),
('about_vision', 'Devenir la référence africaine incontournable en matière de développement urbain intégré et de facilitation financière de projets durables en Afrique Centrale.', 'about'),
('contact_address', 'Avenue de l''Unité, Quartier Himbi, Goma, Nord-Kivu, RD Congo', 'contact'),
('contact_phone1', '+243 900 000 000', 'contact'),
('contact_phone2', '+243 800 000 000', 'contact'),
('contact_email', 'contact@urbanova.cd', 'contact'),
('contact_hours1', 'Lun - Ven : 8h00 - 17h00', 'contact'),
('contact_hours2', 'Sam : 9h00 - 13h00', 'contact'),
('footer_city', 'Goma, RD Congo', 'footer'),
('footer_phone', '+243 900 000 000', 'footer'),
('footer_email', 'contact@urbanova.cd', 'footer'),
('footer_about', 'URBANOVA SOLUTIONS — Développement urbain durable, immobilier et investissements en Afrique Centrale.', 'footer');

SET FOREIGN_KEY_CHECKS = 1;
